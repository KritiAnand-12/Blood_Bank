<header>
    <h1>Blood Donation Initiative</h1>
    <nav>
        <ul>
            <li><a href="/index.html">Home</a></li>
            <li><a href="/register.html">Register as Donor</a></li>
            <li><a href="/region.html">Find a Donor</a></li>
        </ul>
    </nav>
</header>