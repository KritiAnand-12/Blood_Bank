<footer>
    <p>&copy; 2024 Blood Donation Initiative. All rights reserved.</p>
</footer>